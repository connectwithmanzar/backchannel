# Backchannel: notes for Claude Code

## Who you're working with
The owner (Manzar) does not code. Explain every step in plain language, give click-by-click instructions for anything he must do himself (accounts, keys, settings), and run commands for him rather than asking him to. Keep changes small and show what changed.

## What this is
A personal job-search engine for SDR/BDR, GTM Engineer and AE roles. Test phase: one user (the owner) for 90 days. If it lands him a great job, it opens to the public later. Build single-user now, multi-user-ready (user_id + row-level security on every personal table).

Full spec: `docs/backchannel-build-brief.md` (stack, hard rules, data model, screens, and the 10 build prompts in section 9).
Design reference: `docs/backchannel-prototype.html`. Match its screens, colours and copy.

## Status (9 Nov 2026)
Full product built: Today dashboard, Roles (collection from Greenhouse/Lever/Ashby/SmartRecruiters with auto-repair of broken boards), Sources page (add any company by name), Great companies (AI curation + board discovery), Autopilot (AI-tailored CV, cover note, form answers; sensitive questions stop and ask; user submits), Outreach (Gmail OAuth, AI 3-email + 2-LinkedIn-step sequences, approve first email, daily follow-ups, stop on reply, blocklist), Referrals tracker with AI asks, Pay benchmark from published pay, Side income, "Ask Backchannel" AI chat, daily cron (/api/daily: score → autopilot → outreach → Telegram).
- Go-live steps for the owner: `docs/GO-LIVE.md` (run migration 0006, env vars, Google redirect URI, push).
- Key code: `src/lib/jobs/ingest.ts`, `src/lib/collectors/ats.ts`, `src/lib/jobs/scoring.ts`, `src/lib/apps/`, `src/lib/outreach/`, `src/lib/ai.ts` (OPENROUTER_API_KEY or ANTHROPIC_API_KEY).
- Vercel Hobby allows 2 daily crons: /api/collect-jobs (06:00 IST) and /api/daily (07:15 IST).
- Next.js 16: `next lint` is gone; lint with `npx eslint src`.

## Commands
- `npm install`: install dependencies
- `npm run dev`: run the app at http://localhost:3000
- `npm test`: unit tests (17)
- `npx eslint src`: lint
- `npm run build`: production build (run before saying a build step is done)

## Hard rules (from the brief)
1. No LinkedIn automation, login, scraping or stored LinkedIn credentials. LinkedIn steps are copy-ready tasks only.
2. Only public ATS feeds and licensed data providers. No scraping sites that forbid it.
3. Never invent facts about the user in CVs, answers or emails.
4. Visa, work authorisation, salary, notice period and diversity questions always stop and ask the user.
5. Stealth: never contact or surface people at the user's current employer (blocklist).
6. Email: 20/day max to start, send window, stop on reply, opt-out line.
7. Human approval by default; autopilot only when switched on.
8. Keep the job search on personal accounts and tools only, never employer accounts or data.
